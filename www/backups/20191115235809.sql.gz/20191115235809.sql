-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: farmacia
-- ------------------------------------------------------
-- Server version 	5.5.5-10.1.36-MariaDB
-- Date: Fri, 15 Nov 2019 23:58:09 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` int(11) NOT NULL,
  `nome` varchar(55) NOT NULL,
  `dataNascimento` date NOT NULL,
  `endereco` varchar(55) NOT NULL,
  `numero` int(5) NOT NULL,
  `bairro` varchar(55) NOT NULL,
  `telefone` int(11) NOT NULL,
  `celular` int(11) NOT NULL,
  `email` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_clientes`
--

LOCK TABLES `tb_clientes` WRITE;
/*!40000 ALTER TABLE `tb_clientes` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_clientes` VALUES (1,2147483647,'joao','2019-09-11','julio de castilho',36,'centro',37244567,999280448,'a@a.com');
/*!40000 ALTER TABLE `tb_clientes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_clientes` with 1 row(s)
--

--
-- Table structure for table `tb_fornecedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_fornecedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(55) NOT NULL,
  `cnpj` int(20) NOT NULL,
  `inscricao` int(20) NOT NULL,
  `endereco` varchar(55) NOT NULL,
  `numero` int(5) NOT NULL,
  `bairro` varchar(55) NOT NULL,
  `cidade` varchar(55) NOT NULL,
  `cep` int(20) NOT NULL,
  `uf` varchar(2) NOT NULL,
  `telefone` int(11) NOT NULL,
  `email` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_fornecedores`
--

LOCK TABLES `tb_fornecedores` WRITE;
/*!40000 ALTER TABLE `tb_fornecedores` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_fornecedores` VALUES (1,'fornecedor1',2147483647,2147483647,'julio de castilho',836,'centro','cachoeira do sul',96501,'RS',37244567,'a@a.com');
/*!40000 ALTER TABLE `tb_fornecedores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_fornecedores` with 1 row(s)
--

--
-- Table structure for table `tb_lembrete`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_lembrete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`),
  CONSTRAINT `tb_lembrete_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `tb_usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_lembrete`
--

LOCK TABLES `tb_lembrete` WRITE;
/*!40000 ALTER TABLE `tb_lembrete` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_lembrete` VALUES (1,'Recado 01','2019-09-23',2),(2,'recado 2','2019-09-23',1);
/*!40000 ALTER TABLE `tb_lembrete` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_lembrete` with 2 row(s)
--

--
-- Table structure for table `tb_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(55) NOT NULL,
  `codInterno` int(20) NOT NULL,
  `codBarras` int(11) NOT NULL,
  `fornecedor` int(11) NOT NULL,
  `custo` int(11) NOT NULL,
  `venda` int(11) NOT NULL,
  `principio` varchar(55) NOT NULL,
  `quantidade` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_produtos`
--

LOCK TABLES `tb_produtos` WRITE;
/*!40000 ALTER TABLE `tb_produtos` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_produtos` VALUES (1,'remedio ',1,777898888,1,10,18,'axxxxx',3);
/*!40000 ALTER TABLE `tb_produtos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_produtos` with 1 row(s)
--

--
-- Table structure for table `tb_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(55) NOT NULL,
  `usuario` varchar(55) NOT NULL,
  `senha` varchar(55) NOT NULL,
  `cargo` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuarios`
--

LOCK TABLES `tb_usuarios` WRITE;
/*!40000 ALTER TABLE `tb_usuarios` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_usuarios` VALUES (1,'admin','admin','12345','0'),(2,'augusto','augusto','12345','0');
/*!40000 ALTER TABLE `tb_usuarios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_usuarios` with 2 row(s)
--

--
-- Table structure for table `tb_venda_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_venda_produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `n_nota_fiscal` int(11) NOT NULL,
  `codBarras` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `quant` int(11) NOT NULL,
  `valor` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_venda_produtos`
--

LOCK TABLES `tb_venda_produtos` WRITE;
/*!40000 ALTER TABLE `tb_venda_produtos` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_venda_produtos` VALUES (1,32676,777898888,'remedio ',3,18),(2,32676,777898888,'remedio ',3,18),(3,32676,777898888,'remedio ',3,18),(4,32676,777898888,'remedio ',3,18),(5,32676,777898888,'remedio ',3,18),(6,33075234,777898888,'remedio ',3,18),(7,33075234,777898888,'remedio ',3,18),(8,6962323,777898888,'remedio ',3,18),(9,6962323,777898888,'remedio ',3,18),(10,35037225,777898888,'remedio ',1,18),(11,35037225,777898888,'remedio ',1,18),(12,2333322,777898888,'remedio ',1,18),(13,383422,777898888,'remedio ',1,18),(14,383422,777898888,'remedio ',2,18),(15,383422,777898888,'remedio ',2,18),(16,2025723,777898888,'remedio ',1,18),(17,32026,777898888,'remedio ',1,18),(18,2933,777898888,'remedio ',1,18),(19,22323333,777898888,'remedio ',2,18),(20,22323333,777898888,'remedio ',1,18),(21,22323333,777898888,'remedio ',3,18),(22,2003692,777898888,'remedio ',1,18),(23,2003692,777898888,'remedio ',2,18),(24,2003692,777898888,'remedio ',3,18),(25,3750383,777898888,'remedio ',3,18),(26,3750383,777898888,'remedio ',1,18),(27,0,777898888,'remedio ',1,18),(28,0,777898888,'remedio ',1,18),(29,233300,777898888,'remedio ',1,18),(30,233300,777898888,'remedio ',3,18),(31,92322,777898888,'remedio ',1,18),(32,92322,777898888,'remedio ',1,18),(33,92322,777898888,'remedio ',3,18),(34,7232022,777898888,'remedio ',3,18),(35,7232022,777898888,'remedio ',1,18),(36,332203,777898888,'remedio ',1,18),(37,332332,777898888,'remedio ',1,18),(38,4022273,777898888,'remedio ',2,18),(39,80,777898888,'remedio ',1,18),(40,80,777898888,'remedio ',3,18),(41,2022,777898888,'remedio ',1,18),(42,2022,777898888,'remedio ',2,18),(43,2022,777898888,'remedio ',3,18),(44,2022,777898888,'remedio ',3,18),(45,2022,777898888,'remedio ',3,18),(46,93290233,777898888,'remedio ',1,18),(47,93290233,777898888,'remedio ',2,18),(48,0,777898888,'remedio ',1,18),(49,3238092,777898888,'remedio ',3,18),(50,3238092,777898888,'remedio ',1,18),(51,330202,777898888,'remedio ',2,18),(52,62450,777898888,'remedio ',3,18),(53,220273,777898888,'remedio ',1,18),(54,220273,777898888,'remedio ',3,18),(55,332820,777898888,'remedio ',1,18),(56,332820,777898888,'remedio ',1,18),(60,3947225,777898888,'remedio ',2,18),(61,6022033,777898888,'remedio ',1,18),(62,23842,777898888,'remedio ',3,18),(63,342232,777898888,'remedio ',1,18),(64,302320,777898888,'remedio ',2,18),(65,4732233,777898888,'remedio ',2,18),(66,237222,777898888,'remedio ',1,18),(67,32402220,777898888,'remedio ',1,18),(68,32402220,777898888,'remedio ',1,18),(69,2739022,777898888,'remedio ',2,18),(70,22302,777898888,'remedio ',1,18),(71,5233322,777898888,'remedio ',1,18),(72,207033,777898888,'remedio ',1,18),(73,322283,777898888,'remedio ',1,18),(74,32238232,777898888,'remedio ',1,18),(75,483422,777898888,'remedio ',1,18),(76,2027042,777898888,'remedio ',1,18),(77,4673320,777898888,'remedio ',1,18),(78,59343393,777898888,'remedio ',1,18),(79,3220733,777898888,'remedio ',2,18),(80,633230,777898888,'remedio ',2,18),(81,3433200,777898888,'remedio ',1,18),(82,20273,777898888,'remedio ',2,18),(83,3022333,777898888,'remedio ',1,18),(84,20030,777898888,'remedio ',3,18),(85,722,777898888,'remedio ',2,18),(86,39382027,777898888,'remedio ',1,18),(87,3223302,777898888,'remedio ',1,18),(88,702022,777898888,'remedio ',2,18),(89,30332,777898888,'remedio ',1,18),(90,2022597,777898888,'remedio ',1,18),(91,3323,777898888,'remedio ',1,18),(92,3223309,777898888,'remedio ',2,18),(93,823230,777898888,'remedio ',2,18),(94,2007030,777898888,'remedio ',1,18),(95,20830332,777898888,'remedio ',2,18),(96,322232,777898888,'remedio ',2,18),(97,3084323,777898888,'remedio ',2,18),(98,290200,777898888,'remedio ',2,18),(99,3332403,777898888,'remedio ',1,18),(100,724,777898888,'remedio ',2,18),(101,37203299,777898888,'remedio ',1,18),(102,30822330,777898888,'remedio ',1,18),(103,30002988,777898888,'remedio ',2,18),(104,34072,777898888,'remedio ',2,18),(105,223322,777898888,'remedio ',1,18),(106,4354323,777898888,'remedio ',1,18),(107,20232323,777898888,'remedio ',1,18),(108,593,777898888,'remedio ',1,18),(109,750229,777898888,'remedio ',1,18),(110,3720302,777898888,'remedio ',1,18),(111,34022353,777898888,'remedio ',1,18),(112,3032,777898888,'remedio ',1,18),(113,553,777898888,'remedio ',1,18),(114,3250303,777898888,'remedio ',2,18),(115,2230022,777898888,'remedio ',1,18),(116,6335,777898888,'remedio ',1,18),(117,300653,777898888,'remedio ',1,18),(118,3303203,777898888,'remedio ',1,18),(119,5042025,777898888,'remedio ',1,18),(120,42383,777898888,'remedio ',1,18),(121,32252,777898888,'remedio ',1,18),(122,78003,777898888,'remedio ',1,18),(123,3030303,777898888,'remedio ',1,18),(124,830202,777898888,'remedio ',1,18),(125,4022202,777898888,'remedio ',2,18),(126,62733327,777898888,'remedio ',2,18),(127,2523203,777898888,'remedio ',2,18),(128,3338023,777898888,'remedio ',2,18),(129,6232004,777898888,'remedio ',2,18),(130,2342272,777898888,'remedio ',2,18),(131,3302,777898888,'remedio ',1,18),(132,22238523,777898888,'remedio ',2,18),(133,32303,777898888,'remedio ',1,18),(134,36820290,777898888,'remedio ',2,18),(135,3523322,777898888,'remedio ',2,18),(136,733225,777898888,'remedio ',2,18),(137,233209,777898888,'remedio ',1,18),(138,3390223,777898888,'remedio ',2,18),(139,3232,777898888,'remedio ',1,18),(140,3332333,777898888,'remedio ',1,18),(141,3238333,777898888,'remedio ',2,18),(142,728020,777898888,'remedio ',1,18),(143,933320,777898888,'remedio ',1,18),(144,2220,777898888,'remedio ',1,18),(145,20302,777898888,'remedio ',1,18),(146,33023,777898888,'remedio ',2,18),(147,52238773,777898888,'remedio ',1,18),(148,2025232,777898888,'remedio ',2,18);
/*!40000 ALTER TABLE `tb_venda_produtos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_venda_produtos` with 145 row(s)
--

--
-- Table structure for table `tb_vendas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_vendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` varchar(11) NOT NULL,
  `data` date NOT NULL,
  `vendedor` varchar(55) NOT NULL,
  `cliente` varchar(55) DEFAULT NULL,
  `n_NotaFiscal` int(11) NOT NULL,
  `pagamento` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_vendas`
--

LOCK TABLES `tb_vendas` WRITE;
/*!40000 ALTER TABLE `tb_vendas` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_vendas` VALUES (1,'36','2011-01-19','0','Nao Identificado',302320,'Dinheiro'),(2,'36','2011-01-19','0','joao',302320,'Debito'),(3,'36','2011-01-19','0','joao',302320,'Debito'),(4,'36','2011-01-19','0','Nao Identificado',302320,'Dinheiro'),(5,'36','2011-01-19','augusto','Nao Identificado',302320,'Debito'),(6,'36','2011-01-19','augusto','Nao Identificado',4732233,'Dinheiro'),(7,'36','2011-01-19','augusto','Nao Identificado',4732233,'Dinheiro'),(8,'18','2011-01-19','augusto','Nao Identificado',237222,'Dinheiro'),(9,'18','2011-01-19','augusto','joao',237222,'Debito'),(10,'18','2011-01-19','augusto','Nao Identificado',237222,'Dinheiro'),(11,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(12,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(13,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(14,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(15,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(16,'32.76','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(17,'35.64','2011-07-19','augusto','Nao Identificado',2739022,'36'),(18,'17.64','2011-07-19','augusto','Nao Identificado',22302,'Dinheiro'),(19,'17.64','2011-08-19','augusto','Nao Identificado',5233322,'Dinheiro'),(20,'17.64','2019-11-08','augusto','Nao Identificado',207033,'Dinheiro'),(21,'18','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(22,'18','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(23,'18','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(24,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(25,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(26,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(27,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(28,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(29,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(30,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(31,'17.46','2019-11-13','augusto','Nao Identificado',322283,'Dinheiro'),(62,'17.46','2019-11-13','augusto','Nao Identificado',483422,'Dinheiro'),(63,'17.64','2019-11-13','augusto','joao',483422,'Dinheiro'),(64,'17.64','2019-11-13','augusto','Nao Identificado',59343393,'Dinheiro'),(65,'17.64','2019-11-13','augusto','Nao Identificado',59343393,'Dinheiro'),(66,'17.64','2019-11-13','augusto','joao',3220733,'Dinheiro'),(67,'17.64','2019-11-13','augusto','joao',3220733,'Dinheiro'),(68,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(69,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(70,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(71,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(72,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(73,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(74,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(75,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(76,'17.64','2019-11-13','augusto','Nao Identificado',3220733,'Dinheiro'),(77,'17.64','2019-11-13','augusto','joao',633230,'Debito'),(78,'17.64','2019-11-13','augusto','Nao Identificado',3433200,'Dinheiro'),(79,'35.28','2019-11-13','augusto','joao',20273,'Dinheiro'),(80,'35.28','2019-11-13','augusto','Nao Identificado',3022333,'Dinheiro'),(81,'35.28','2019-11-13','augusto','Nao Identificado',20030,'Dinheiro'),(82,'1','2019-11-13','augusto','Nao Identificado',722,'Dinheiro'),(83,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(84,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(85,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(86,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(87,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(88,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(89,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(90,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(91,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(92,'1','2019-11-13','augusto','Nao Identificado',39382027,'Dinheiro'),(93,'1','2019-11-13','augusto','Nao Identificado',3223302,'Dinheiro'),(94,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(95,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(96,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(97,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(98,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(99,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(100,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(101,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(102,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(103,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(104,'1','2019-11-13','augusto','Nao Identificado',702022,'Dinheiro'),(105,'1','2019-11-13','augusto','Nao Identificado',30332,'Dinheiro'),(106,'1','2019-11-13','augusto','Nao Identificado',30332,'Dinheiro'),(107,'1','2019-11-13','augusto','Nao Identificado',2022597,'Dinheiro'),(108,'1','2019-11-13','augusto','Nao Identificado',2022597,'Dinheiro'),(109,'1','2019-11-13','augusto','Nao Identificado',3323,'Dinheiro'),(110,'1','2019-11-13','augusto','Nao Identificado',3323,'Dinheiro'),(111,'1','2019-11-13','augusto','Nao Identificado',3323,'Dinheiro'),(112,'1','2019-11-13','augusto','Nao Identificado',3323,'Dinheiro'),(113,'1','2019-11-13','augusto','Nao Identificado',3323,'Dinheiro'),(114,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(115,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(116,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(117,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(118,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(119,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(120,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(121,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(122,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(123,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(124,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(125,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(126,'1','2019-11-13','augusto','Nao Identificado',3223309,'Dinheiro'),(127,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(128,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(129,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(130,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(131,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(132,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(133,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(134,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(135,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(136,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(137,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(138,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(139,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(140,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(141,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(142,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(143,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(144,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(145,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(146,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(147,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(148,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(149,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(150,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(151,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(152,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(153,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(154,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(155,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(156,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(157,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(158,'1','2019-11-13','augusto','Nao Identificado',823230,'Dinheiro'),(159,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(160,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(161,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(162,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(163,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(164,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(165,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(166,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(167,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(168,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(169,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(170,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(171,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(172,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(173,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(174,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(175,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(176,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(177,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(178,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(179,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(180,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(181,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(182,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(183,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(184,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(185,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(186,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(187,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(188,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(189,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(190,'1','2019-11-13','augusto','Nao Identificado',2007030,'Dinheiro'),(191,'36','2019-11-14','augusto','Nao Identificado',30002988,'Dinheiro'),(192,'36','2019-11-14','augusto','joao',34072,'Dinheiro'),(193,'36','2019-11-14','augusto','Nao Identificado',34072,'Dinheiro'),(194,'36','2019-11-14','augusto','Nao Identificado',34072,'Dinheiro'),(195,'36','2019-11-14','augusto','Nao Identificado',34072,'Dinheiro'),(196,'36','2019-11-14','augusto','Nao Identificado',34072,'Dinheiro'),(197,'18','2019-11-14','augusto','Nao Identificado',223322,'Dinheiro'),(198,'18','2019-11-14','augusto','Nao Identificado',593,'Dinheiro'),(199,'18','2019-11-14','augusto','Nao Identificado',750229,'Dinheiro'),(200,'18','2019-11-14','augusto','Nao Identificado',750229,'Dinheiro'),(201,'18','2019-11-14','augusto','Nao Identificado',3720302,'Dinheiro'),(202,'18','2019-11-14','augusto','Nao Identificado',3720302,'Dinheiro'),(203,'18','2019-11-14','augusto','Nao Identificado',34022353,'Dinheiro'),(204,'18','2019-11-14','augusto','Nao Identificado',3032,'Dinheiro'),(205,'18','2019-11-14','augusto','Nao Identificado',553,'Dinheiro'),(206,'18','2019-11-14','augusto','Nao Identificado',553,'Dinheiro'),(207,'18','2019-11-14','augusto','Nao Identificado',553,'Dinheiro'),(208,'18','2019-11-14','augusto','Nao Identificado',553,'Dinheiro'),(209,'18','2019-11-14','augusto','Nao Identificado',553,'Dinheiro'),(210,'36','2019-11-14','augusto','Nao Identificado',3250303,'Dinheiro'),(211,'18','2019-11-14','augusto','Nao Identificado',2230022,'Dinheiro'),(212,'18','2019-11-14','augusto','Nao Identificado',2230022,'Dinheiro'),(213,'18','2019-11-14','augusto','Nao Identificado',300653,'Dinheiro'),(214,'18','2019-11-14','augusto','Nao Identificado',3303203,'Dinheiro'),(215,'18','2019-11-14','augusto','Nao Identificado',3303203,'Dinheiro'),(216,'18','2019-11-14','augusto','Nao Identificado',42383,'Dinheiro'),(217,'36','2019-11-14','augusto','Nao Identificado',6232004,'Dinheiro'),(218,'36','2019-11-14','augusto','Nao Identificado',2342272,'Dinheiro'),(219,'10','2019-11-14','augusto','Nao Identificado',22238523,'Dinheiro'),(220,'10','2019-11-14','augusto','Nao Identificado',22238523,'Dinheiro'),(221,'18','2019-11-14','augusto','Nao Identificado',233209,'Dinheiro'),(222,'18','2019-11-14','augusto','Nao Identificado',233209,'Dinheiro'),(223,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(224,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(225,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(226,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(227,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(228,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(229,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(230,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(231,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(232,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(233,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(234,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(235,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(236,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(237,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(238,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(239,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(240,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(241,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(242,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(243,'54','2019-11-15','augusto','Nao Identificado',0,'Dinheiro'),(244,'18','2019-11-15','augusto','Nao Identificado',3232,'Dinheiro'),(245,'18','2019-11-15','augusto','Nao Identificado',3232,'Dinheiro'),(246,'18','2019-11-15','augusto','Nao Identificado',933320,'Dinheiro'),(247,'18','0000-00-00','augusto','Nao Identificado',2220,'Dinheiro'),(248,'18','0000-00-00','augusto','Nao Identificado',20302,'Dinheiro'),(249,'36','0000-00-00','augusto','Nao Identificado',33023,'Dinheiro'),(250,'18','0000-00-00','augusto','Nao Identificado',52238773,'Dinheiro'),(251,'36','0000-00-00','augusto','Nao Identificado',2025232,'Dinheiro'),(252,'36','0000-00-00','augusto','Nao Identificado',2025232,'Dinheiro');
/*!40000 ALTER TABLE `tb_vendas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_vendas` with 222 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Fri, 15 Nov 2019 23:58:09 +0100
