-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: farmacia
-- ------------------------------------------------------
-- Server version 	5.7.33
-- Date: Sun, 05 Sep 2021 03:06:48 +0000

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` int(11) NOT NULL,
  `nome` varchar(55) NOT NULL,
  `dataNascimento` date NOT NULL,
  `endereco` varchar(55) NOT NULL,
  `numero` int(5) NOT NULL,
  `bairro` varchar(55) NOT NULL,
  `telefone` int(11) NOT NULL,
  `celular` int(11) NOT NULL,
  `email` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_clientes`
--

LOCK TABLES `tb_clientes` WRITE;
/*!40000 ALTER TABLE `tb_clientes` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_clientes` VALUES (1,2147483647,'joao','2019-09-11','julio de castilho',36,'centro',37244567,999280448,'a@a.com');
/*!40000 ALTER TABLE `tb_clientes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_clientes` with 1 row(s)
--

--
-- Table structure for table `tb_fornecedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_fornecedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(55) NOT NULL,
  `cnpj` int(20) NOT NULL,
  `inscricao` int(20) NOT NULL,
  `endereco` varchar(55) NOT NULL,
  `numero` int(5) NOT NULL,
  `bairro` varchar(55) NOT NULL,
  `cidade` varchar(55) NOT NULL,
  `cep` int(20) NOT NULL,
  `uf` varchar(2) NOT NULL,
  `telefone` int(11) NOT NULL,
  `email` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_fornecedores`
--

LOCK TABLES `tb_fornecedores` WRITE;
/*!40000 ALTER TABLE `tb_fornecedores` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_fornecedores` VALUES (1,'fornecedor1',2147483647,2147483647,'julio de castilho',836,'centro','cachoeira do sul',96501,'RS',37244567,'a@a.com');
/*!40000 ALTER TABLE `tb_fornecedores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_fornecedores` with 1 row(s)
--

--
-- Table structure for table `tb_lembrete`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_lembrete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`),
  CONSTRAINT `tb_lembrete_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `tb_usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_lembrete`
--

LOCK TABLES `tb_lembrete` WRITE;
/*!40000 ALTER TABLE `tb_lembrete` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_lembrete` VALUES (1,'Un message 01','2019-09-23',2),(2,'Un message 2','2019-09-23',1);
/*!40000 ALTER TABLE `tb_lembrete` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_lembrete` with 2 row(s)
--

--
-- Table structure for table `tb_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(55) NOT NULL,
  `codInterno` varchar(225) NOT NULL,
  `codBarras` varchar(225) NOT NULL,
  `fornecedor` int(11) NOT NULL,
  `custo` int(11) NOT NULL,
  `venda` int(11) NOT NULL,
  `principio` varchar(55) NOT NULL,
  `quantidade` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_produtos`
--

LOCK TABLES `tb_produtos` WRITE;
/*!40000 ALTER TABLE `tb_produtos` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_produtos` VALUES (3,'Amoxi','df251','123456789',1,100,300,'andrana',50),(4,'Paracetamol','dfs212','222222222',1,300,500,'antibiotique',40);
/*!40000 ALTER TABLE `tb_produtos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_produtos` with 2 row(s)
--

--
-- Table structure for table `tb_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(55) NOT NULL,
  `usuario` varchar(55) NOT NULL,
  `senha` varchar(55) NOT NULL,
  `cargo` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuarios`
--

LOCK TABLES `tb_usuarios` WRITE;
/*!40000 ALTER TABLE `tb_usuarios` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_usuarios` VALUES (1,'admin','admin','12345','0'),(2,'augusto','augusto','12345','0');
/*!40000 ALTER TABLE `tb_usuarios` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_usuarios` with 2 row(s)
--

--
-- Table structure for table `tb_venda_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_venda_produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `n_nota_fiscal` int(11) NOT NULL,
  `codBarras` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `quant` int(11) NOT NULL,
  `valor` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_venda_produtos`
--

LOCK TABLES `tb_venda_produtos` WRITE;
/*!40000 ALTER TABLE `tb_venda_produtos` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_venda_produtos` VALUES (1,32676,777898888,'remedio ',3,18),(2,32676,777898888,'remedio ',3,18),(3,32676,777898888,'remedio ',3,18),(4,32676,777898888,'remedio ',3,18),(5,32676,777898888,'remedio ',3,18),(6,33075234,777898888,'remedio ',3,18),(7,33075234,777898888,'remedio ',3,18),(8,6962323,777898888,'remedio ',3,18),(9,6962323,777898888,'remedio ',3,18),(10,35037225,777898888,'remedio ',1,18),(11,35037225,777898888,'remedio ',1,18),(12,2333322,777898888,'remedio ',1,18),(13,383422,777898888,'remedio ',1,18),(14,383422,777898888,'remedio ',2,18),(15,383422,777898888,'remedio ',2,18),(16,2025723,777898888,'remedio ',1,18),(17,32026,777898888,'remedio ',1,18),(18,2933,777898888,'remedio ',1,18),(19,22323333,777898888,'remedio ',2,18),(20,22323333,777898888,'remedio ',1,18),(21,22323333,777898888,'remedio ',3,18),(22,2003692,777898888,'remedio ',1,18),(23,2003692,777898888,'remedio ',2,18),(24,2003692,777898888,'remedio ',3,18),(25,3750383,777898888,'remedio ',3,18),(26,3750383,777898888,'remedio ',1,18),(27,0,777898888,'remedio ',1,18),(28,0,777898888,'remedio ',1,18),(29,233300,777898888,'remedio ',1,18),(30,233300,777898888,'remedio ',3,18),(31,92322,777898888,'remedio ',1,18),(32,92322,777898888,'remedio ',1,18),(33,92322,777898888,'remedio ',3,18),(34,7232022,777898888,'remedio ',3,18),(35,7232022,777898888,'remedio ',1,18),(36,332203,777898888,'remedio ',1,18),(37,332332,777898888,'remedio ',1,18),(38,4022273,777898888,'remedio ',2,18),(39,80,777898888,'remedio ',1,18),(40,80,777898888,'remedio ',3,18),(41,2022,777898888,'remedio ',1,18),(42,2022,777898888,'remedio ',2,18),(43,2022,777898888,'remedio ',3,18),(44,2022,777898888,'remedio ',3,18),(45,2022,777898888,'remedio ',3,18),(46,93290233,777898888,'remedio ',1,18),(47,93290233,777898888,'remedio ',2,18),(48,0,777898888,'remedio ',1,18),(49,3238092,777898888,'remedio ',3,18),(50,3238092,777898888,'remedio ',1,18),(51,330202,777898888,'remedio ',2,18),(52,62450,777898888,'remedio ',3,18),(53,220273,777898888,'remedio ',1,18),(54,220273,777898888,'remedio ',3,18),(55,332820,777898888,'remedio ',1,18),(56,332820,777898888,'remedio ',1,18),(60,3947225,777898888,'remedio ',2,18),(61,6022033,777898888,'remedio ',1,18),(62,23842,777898888,'remedio ',3,18),(63,342232,777898888,'remedio ',1,18),(64,302320,777898888,'remedio ',2,18),(65,4732233,777898888,'remedio ',2,18),(66,237222,777898888,'remedio ',1,18),(67,32402220,777898888,'remedio ',1,18),(68,32402220,777898888,'remedio ',1,18),(69,2739022,777898888,'remedio ',2,18),(70,22302,777898888,'remedio ',1,18),(71,37260390,777898888,'remedio ',1,18),(74,33936233,777898888,'remedio ',2,18),(75,9000532,777898888,'remedio ',1,18),(76,3227,777898888,'remedio ',1,18),(77,33032,777898888,'remedio ',1,18),(78,33032,777898888,'remedio ',4,18),(79,33320836,777898888,'remedio ',1,18),(80,232320,777898888,'remedio ',1,18),(81,232320,777898888,'remedio ',1,18),(82,232320,777898888,'remedio ',3,18),(83,2300882,777898888,'remedio ',1,18),(84,3223,123456789,'Amoxi',1,300),(85,4300707,123456789,'Amoxi',2,300),(86,4300707,222222222,'Paracetamol',3,500),(87,830083,123456789,'Amoxi',1,300);
/*!40000 ALTER TABLE `tb_venda_produtos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_venda_produtos` with 82 row(s)
--

--
-- Table structure for table `tb_vendas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_vendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` varchar(11) NOT NULL,
  `data` date NOT NULL,
  `vendedor` varchar(55) NOT NULL,
  `cliente` varchar(55) DEFAULT NULL,
  `n_NotaFiscal` int(11) NOT NULL,
  `pagamento` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_vendas`
--

LOCK TABLES `tb_vendas` WRITE;
/*!40000 ALTER TABLE `tb_vendas` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tb_vendas` VALUES (1,'36','2011-01-19','0','Nao Identificado',302320,'Dinheiro'),(2,'36','2011-01-19','0','joao',302320,'Debito'),(3,'36','2011-01-19','0','joao',302320,'Debito'),(4,'36','2011-01-19','0','Nao Identificado',302320,'Dinheiro'),(5,'36','2011-01-19','augusto','Nao Identificado',302320,'Debito'),(6,'36','2011-01-19','augusto','Nao Identificado',4732233,'Dinheiro'),(7,'36','2011-01-19','augusto','Nao Identificado',4732233,'Dinheiro'),(8,'18','2011-01-19','augusto','Nao Identificado',237222,'Dinheiro'),(9,'18','2011-01-19','augusto','joao',237222,'Debito'),(10,'18','2011-01-19','augusto','Nao Identificado',237222,'Dinheiro'),(11,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(12,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(13,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(14,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(15,'32.4','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(16,'32.76','2011-01-19','augusto','Nao Identificado',32402220,'Dinheiro'),(17,'35.64','2011-07-19','augusto','Nao Identificado',2739022,'36'),(18,'17.64','2011-07-19','augusto','Nao Identificado',22302,'Dinheiro'),(19,'36','2004-09-21','admin','Non identifié',33936233,'De l\'argent'),(20,'36','2004-09-21','admin','Non identifié',33936233,'De l\'argent'),(21,'36','2004-09-21','admin','Non identifié',33936233,'De l\'argent'),(22,'36','2004-09-21','admin','Non identifié',33936233,'De l\'argent'),(23,'18','2004-09-21','admin','joao',9000532,'De l\'argent'),(24,'18','2004-09-21','admin','Non identifié',3227,'De l\'argent'),(25,'18','2004-09-21','admin','Non identifié',3227,'De l\'argent'),(26,'18','2004-09-21','admin','Non identifié',3227,'De l\'argent'),(27,'18','2004-09-21','admin','Non identifié',3227,'De l\'argent'),(28,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(29,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(30,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(31,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(32,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(33,'','2004-09-21','admin','Non identifié',2375035,'De l\'argent'),(34,'90','2004-09-21','admin','Non identifié',33032,'Carte de débit'),(35,'90','2004-09-21','admin','Non identifié',33032,'Carte de débit'),(36,'90','2004-09-21','admin','Non identifié',33032,'Carte de débit'),(37,'90','2004-09-21','admin','Non identifié',33032,'Carte de débit'),(38,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(39,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(40,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(41,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(42,'90','2004-09-21','admin','Non identifié',33032,'Carte de débit'),(43,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(44,'90','2004-09-21','admin','Non identifié',33032,'De l\'argent'),(45,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(46,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(47,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(48,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(49,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(50,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(51,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(52,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(53,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(54,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(55,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(56,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(57,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(58,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(59,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(60,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(61,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(62,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(63,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(64,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(65,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(66,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(67,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(68,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(69,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(70,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(71,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(72,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(73,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(74,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(75,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(76,'18','2004-09-21','admin','Non identifié',33320836,'De l\'argent'),(77,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(78,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(79,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(80,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(81,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(82,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(83,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(84,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(85,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(86,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(87,'18','2005-09-21','admin','Non identifié',33320836,'De l\'argent'),(88,'90','2005-09-21','admin','joao',232320,'Carte de débit'),(89,'300','2005-09-21','admin','joao',3223,'De l\'argent'),(90,'2100','2005-09-21','admin','joao',4300707,'De l\'argent');
/*!40000 ALTER TABLE `tb_vendas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tb_vendas` with 90 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Sun, 05 Sep 2021 03:06:48 +0000
